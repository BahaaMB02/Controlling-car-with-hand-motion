/*
 * Uart.c
 *
 * Created: 8/27/2022 10:04:54 PM
 *  Author: abdala abdelatif
 */ 

#include "Uart.h"
void Uart_Initilization (uint16_t Baud_Rate){
	DDRD &=~(1<<0);
	DDRD |= (1<<1);
	uint16_t UBRR_Value = ((1000000/Baud_Rate)-1);
	UBRRL = (uint8_t) UBRR_Value;
	UBRRH = (uint8_t) (UBRR_Value >> 8);
	UCSRB = (1<<RXEN) | (1<<TXEN);
	UCSRC |= (3<<UCSZ0);
}

uint8_t Uart_Recieve (void) {
	
	while (! (UCSRA & (1 << RXC)));
	return(UDR);
	
}

void UART_send_char(char data)
{
	while( ! (UCSRA & (1<<UDRE) ) );
	UDR = data;
}

void UART_send_string(char *data)
{
	while(*data > 0)
	UART_send_char(*data++);
	UART_send_char('\0');
}