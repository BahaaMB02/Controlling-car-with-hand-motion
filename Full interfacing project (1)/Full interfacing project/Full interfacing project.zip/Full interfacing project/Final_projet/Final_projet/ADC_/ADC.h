/*
 * ADC.h
 *
 * Created: 8/30/2022 10:31:19 PM
 *  Author: abdala abdelatif
 */ 

#include "Cpu_Configuration.h"
#ifndef ADC_H_
#define ADC_H_

void ADC_Initilization (void);



#endif /* ADC_H_ */