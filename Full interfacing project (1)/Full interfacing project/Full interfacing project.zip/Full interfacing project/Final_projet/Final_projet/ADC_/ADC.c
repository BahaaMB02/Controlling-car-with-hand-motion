/*
 * ADC.c
 *
 * Created: 8/30/2022 10:29:31 PM
 *  Author: abdala abdelatif
 */ 
#include "ADC.h"

void ADC_Initilization (void){
	DDRA = 0x00;
	DDRC = 0xff;
	ADCSRA= 0x8F;

	sei();
	ADCSRA |= (1 << ADPS0) | (1 << ADPS1) | (1 << ADPS2);

	ADMUX |= (1 << ADLAR);

	ADMUX |= (1 << MUX0);
	ADCSRA |= (1 << ADSC);
	
}