/*
 * Cpu_Configuration.h
 *
 * Created: 8/27/2022 10:03:17 PM
 *  Author: abdala abdelatif
 */ 


#ifndef CPU_CONFIGURATION_H_
#define CPU_CONFIGURATION_H_

#define F_CPU 16000000
#include <avr/io.h>
#include "stdio.h"
#include "avr/interrupt.h"
#include <util/delay.h>
#include "Uart.h"
#include <stdlib.h>
#include "ADC.h"
#endif /* CPU_CONFIGURATION_H_ */