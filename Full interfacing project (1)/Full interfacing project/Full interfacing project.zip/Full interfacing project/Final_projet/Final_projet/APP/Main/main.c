	/*
	* main.c
	*
	* Created: 8/27/2022 9:00:19 PM
	*  Author: abdala abdelatif
	*/ 


	#include "Cpu_Configuration.h"

	volatile uint8_t adcValue;

	ISR(ADC_vect){
	
	adcValue = ADCH;
	PORTC = adcValue;
	ADCSRA |= (1 << ADSC);
	}

	int main(void)
	{	ADC_Initilization();
		Uart_Initilization(9600);
	
	while(1)
	{
		if (adcValue==0X52)
		{
			UART_send_char((adcValue));
				_delay_ms(1000);
			adcValue = 0 ;
		}
	}
	return 0;
	}

